Source files for a custom build of gwt google maps. You would need these to recompile the gwt maps jar after upgrading the app to a new version of gwt.

To build the new maps jar, copy the new GWT version jars (gwt-user.jar, gwt-dev.jar) into the lib/ directory, then build the maps jar by running 'ant package' from the base directory. The new gwt-google-maps-v3.jar will be saved into target/.

Notes(2012/02/14):
Maps v3 is not officially supported yet and there are wrappers online, but none of them had all the features the app was using from Maps v2. The most popular wrapper (http://code.google.com/p/gwt-google-maps-v3/), for instance, did not allow adding widgets to the info window. The source here is an adaptation of that wrapper done by jhicks, with changes made to:
client/base/InfoWindow.java
client/event/Event.java
client/event/impl/EventImpl.java

If/When the newest version of gwt maps is fully supported, the app can be converted to use the official version instead.
